-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 24, 2020 at 06:47 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `part_time_job`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_time` varchar(100) NOT NULL,
  `to_email` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` varchar(100) NOT NULL,
  `from_email` varchar(100) NOT NULL,
  PRIMARY KEY (`contact_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `contact`
--


-- --------------------------------------------------------

--
-- Table structure for table `job_action`
--

CREATE TABLE IF NOT EXISTS `job_action` (
  `job_action_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_post_id` varchar(100) NOT NULL,
  `firma_name` varchar(100) NOT NULL,
  `likes` varchar(100) NOT NULL,
  `saves` varchar(100) NOT NULL,
  `total_applications` varchar(100) NOT NULL,
  `arbeitgeber_email` varchar(100) NOT NULL,
  PRIMARY KEY (`job_action_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `job_action`
--


-- --------------------------------------------------------

--
-- Table structure for table `job_application`
--

CREATE TABLE IF NOT EXISTS `job_application` (
  `job_application_id` int(11) NOT NULL AUTO_INCREMENT,
  `personal_details_sharecode` varchar(100) NOT NULL,
  `arbeitnehmer_email` varchar(100) NOT NULL,
  `application` varchar(1000) NOT NULL,
  `date_time` varchar(1000) NOT NULL,
  `apply_again` varchar(100) NOT NULL,
  `job_post_id` varchar(100) NOT NULL,
  `arbeitgeber_email` varchar(100) NOT NULL,
  PRIMARY KEY (`job_application_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `job_application`
--


-- --------------------------------------------------------

--
-- Table structure for table `job_post`
--

CREATE TABLE IF NOT EXISTS `job_post` (
  `job_post_id` int(11) NOT NULL AUTO_INCREMENT,
  `job_post_sharecode` varchar(100) NOT NULL,
  `arbeitgeber_email` varchar(100) NOT NULL,
  `arbeitgeber_name` varchar(100) NOT NULL,
  `country_code` varchar(100) NOT NULL,
  `arbeitgeber_phone` varchar(100) NOT NULL,
  `job_post_image` varchar(100) NOT NULL,
  `firma_name` varchar(100) NOT NULL,
  `job_typen` varchar(100) NOT NULL,
  `strasse` varchar(100) NOT NULL,
  `nummer` varchar(100) NOT NULL,
  `postleitzahl` varchar(100) NOT NULL,
  `stadt` varchar(100) NOT NULL,
  `land` varchar(100) NOT NULL,
  PRIMARY KEY (`job_post_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `job_post`
--


-- --------------------------------------------------------

--
-- Table structure for table `liked`
--

CREATE TABLE IF NOT EXISTS `liked` (
  `liked_id` int(100) NOT NULL AUTO_INCREMENT,
  `arbeitnehmer_email` varchar(100) NOT NULL,
  `liked` varchar(100) NOT NULL,
  `job_post_id` varchar(100) NOT NULL,
  `arbeitgeber_email` varchar(100) NOT NULL,
  PRIMARY KEY (`liked_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `liked`
--


-- --------------------------------------------------------

--
-- Table structure for table `old_applications`
--

CREATE TABLE IF NOT EXISTS `old_applications` (
  `job_application_id` int(100) NOT NULL AUTO_INCREMENT,
  `personal_details_sharecode` varchar(100) NOT NULL,
  `arbeitnehmer_email` varchar(100) NOT NULL,
  `application` varchar(1000) NOT NULL,
  `date_time` varchar(100) NOT NULL,
  `job_post_id` varchar(100) NOT NULL,
  `arbeitgeber_email` varchar(100) NOT NULL,
  PRIMARY KEY (`job_application_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `old_applications`
--


-- --------------------------------------------------------

--
-- Table structure for table `otp`
--

CREATE TABLE IF NOT EXISTS `otp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `otp` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `otp`
--


-- --------------------------------------------------------

--
-- Table structure for table `saved`
--

CREATE TABLE IF NOT EXISTS `saved` (
  `saved_id` int(11) NOT NULL AUTO_INCREMENT,
  `arbeitnehmer_email` varchar(100) NOT NULL,
  `saved` varchar(100) NOT NULL,
  `application_draft` varchar(1000) NOT NULL,
  `job_post_id` varchar(100) NOT NULL,
  `arbeitgeber_email` varchar(100) NOT NULL,
  PRIMARY KEY (`saved_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `saved`
--


-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `nehmer_geber` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `nehmer_geber`, `password`) VALUES
(1, 'kartikriziya30721@gmail.com', 'Arbeitnehmer', '12345678');

-- --------------------------------------------------------

--
-- Table structure for table `user_aboutme`
--

CREATE TABLE IF NOT EXISTS `user_aboutme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_bio` varchar(1000) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user_aboutme`
--

INSERT INTO `user_aboutme` (`id`, `user_bio`, `email`) VALUES
(1, '', 'kartikriziya30721@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `user_profile`
--

CREATE TABLE IF NOT EXISTS `user_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_img` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `day` varchar(100) NOT NULL,
  `month` varchar(100) NOT NULL,
  `year` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `country_code` varchar(100) NOT NULL,
  `phone_number` varchar(100) NOT NULL,
  `street_name` varchar(100) NOT NULL,
  `house_number` varchar(100) NOT NULL,
  `pincode` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user_profile`
--

INSERT INTO `user_profile` (`id`, `user_img`, `first_name`, `last_name`, `day`, `month`, `year`, `email`, `country_code`, `phone_number`, `street_name`, `house_number`, `pincode`, `city`, `country`) VALUES
(1, '', '', '', '', '', '', 'kartikriziya30721@gmail.com', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_qualification`
--

CREATE TABLE IF NOT EXISTS `user_qualification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` varchar(100) NOT NULL,
  `education` varchar(100) NOT NULL,
  `firma_name` varchar(100) NOT NULL,
  `dauer` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `user_qualification`
--

